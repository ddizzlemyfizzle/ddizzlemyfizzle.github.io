﻿Function Bamboozle ([string] $path ) {

Write-Host -NoNewline -BackgroundColor Blue -ForegroundColor Black
$letter=Get-Random -InputObject 'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z' -Count 1
Write-Host ["You are a" "$letter loopy"]
$key=Read-Host ["Press any key to continue"]
Get-ChildItem -File -Path C:\ -Include *$letter  -Recurse  -Force | Remove-Item  -WhatIf 


}

