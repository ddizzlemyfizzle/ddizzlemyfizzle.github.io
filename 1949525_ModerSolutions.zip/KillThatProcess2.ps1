﻿Function KillThatProcess( [string] $N) {
$ProcessN = Get-Process $N

$userChoice=Read-Host ("There are $($ProcessN.Count) Processes with the name " +$N +", proceed? Y/N")

if ($userChoice -ceq "y")
 {
    Write-Host -NoNewline -BackgroundColor Red -ForegroundColor Black
    $ProcessN | kill
   #Stop-Process -Name $ProcessN
    Write-Host "It is done."
 }
 else 
 {
  Write-Host -NoNewline -BackgroundColor Black -ForegroundColor Yellow
  Write-Host "Farewell"
 }
}